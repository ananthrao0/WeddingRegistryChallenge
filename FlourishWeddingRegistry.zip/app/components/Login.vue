<!-- I used online resources, including NativeScript built-in challenge code and other free NativeScript services to help build the sign up page -->
<template>
    <Page actionBarHidden="true">
        <FlexboxLayout class="page" backgroundColor="lightyellow">
            <StackLayout class="form">
                <Image class="logo" src="~/images/logo.png"></Image>
                <Label class="header" text="Wedding Registry"></Label>

                <GridLayout rows="auto, auto, auto">
                    <StackLayout row="0" class="input-field">
                        <TextField class="input" hint="Email"
                            :isEnabled="!processing" keyboardType="email"
                            autocorrect="false" autocapitalizationType="none"
                            v-model="user.email" returnKeyType="next"
                            @returnPress="focusPassword"></TextField>
                        <StackLayout class="hr-light"></StackLayout>
                    </StackLayout>

                    <StackLayout row="1" class="input-field">
                        <TextField class="input" ref="password"
                            :isEnabled="!processing" hint="Password"
                            secure="true" v-model="user.password"
                            :returnKeyType="isLoggingIn ? 'done' : 'next'"
                            @returnPress="focusConfirmPassword"></TextField>
                        <StackLayout class="hr-light"></StackLayout>
                    </StackLayout>

                    <StackLayout row="2" v-show="isLoggingIn"
                        class="input-field">
                        <TextField class="input" ref="confirmPassword"
                            :isEnabled="!processing" hint="Confirm password"
                            secure="true" v-model="user.confirmPassword"
                            returnKeyType="done"></TextField>
                        <StackLayout class="hr-light"></StackLayout>
                    </StackLayout>

                    <ActivityIndicator rowSpan="3" :busy="processing">
                    </ActivityIndicator>
                </GridLayout>

                <Button text="Sign Up"
                    @tap="submit" class="btn btn-primary m-t-20"></Button>
            </StackLayout>

        </FlexboxLayout>
    </Page>
</template>

<script>
    import Home from "./Home";
    import Cart from "./Cart";
    export default {
        data() {
            return {
                isLoggingIn: true,
                processing: false,
                user: {
                    email: "",
                    password: "",
                    confirmPassword: ""
                }
            };
        },
        methods: {
            submit() {
                if (!this.user.email || !this.user.password) {
                    this.alert(
                        "Please provide both an email address and password."
                    );
                    return;
                } else if (
                    !this.user.email.includes("@") ||
                    !this.user.email.includes(".")
                ) {
                    this.alert("Please enter a valid email.");
                    return;
                } else if (!this.user.confirmPassword) {
                    this.alert("Please confirm your password.");
                    return;
                } else if (!(this.user.confirmPassword.valueOf() == this.user.password.valueOf())) {
                    this.alert("Password confirmation does not match password.");
                    return;
                }
                this.processing = true;
                if (this.isLoggingIn) {
                    this.login();
                }
            },

            login() {
                this.$navigateTo(Home, {
                    clearHistory: true
                });
                this.processing = false;
            },

            alert(message) {
                return alert({
                    title: "Wedding Registry",
                    okButtonText: "OK",
                    message: message
                });
            }
        }
    };
</script>

<style scoped>
    .page {
        align-items: center;
        flex-direction: column;
    }

    .form {
        margin-left: 30;
        margin-right: 30;
        flex-grow: 2;
        vertical-align: middle;
    }

    .logo {
        margin-bottom: 12;
        height: 90;
        font-weight: bold;
    }

    .input-field {
        margin-bottom: 25;
    }

    .input {
        font-size: 18;
        placeholder-color: #A8A8A8;
    }

    .input:disabled {
        background-color: white;
        opacity: 0.5;
    }

    .btn-primary {
        margin: 30 5 15 5;
    }

    .login-label {
        horizontal-align: center;
        color: #A8A8A8;
        font-size: 16;
    }

    .sign-up-label {
        margin-bottom: 20;
    }

    .bold {
        color: #000000;
    }
</style>