<template>
    <Page>
        <ActionBar title="Wedding Registry"></ActionBar>
        <ScrollView>
            <StackLayout backgroundColor="lightyellow">
                <Image class="logo" src="~/images/shoppingcart.png"></Image>
                <Label class="body m-20" color="black" text="The items you have purchased:"
                    textWrap="true">
                </Label>
                <Label class="productName" horizontalAlignment="center" v-for="item in itemsBought"
                    :text="item" textWrap="true">
                </Label>
                <Label class="body m-20" textWrap="true"
                    horizontalAlignment="center">The value of the items in
                    your cart is ${{ cartSize }}. Your budget is
                    ${{ budget }}.</Label>
                <!--         <Label class="body m-20" :text="itemsBought" textWrap="true">
            </Label> -->
                <Button horizontalAlignment="center" @tap="purchase"
                    text="Purchase" class="btn btn-primary m-t-50"
                    :isEnabled="cartSize <= budget">
                </Button>
                <Label class="body m-20" text="" textWrap="true">
                </Label>
                <Button text="Clear Cart" class="btn-primary" @tap="clear" />
            </StackLayout>
        </ScrollView>
    </Page>
</template>

<script>
    import Login from "./Login";
    import {
        store
    } from "../store.js";
    import Home from "./Home";
    export default {
        data() {
            return {
                itemsBought: this.$store.state.itemsBought,
                cartSize: this.$store.state.cartSize,
                budget: this.$store.state.budget
            };
        },
        store,
        computed: {
            count() {
                console.log(this.$store.state.itemsBought);
                return this.$store.state.count.toString();
            }
        },
        methods: {
            purchase() {
                this.$store.commit("decreaseBudget", this.$store.state
                    .cartSize);
                this.$store.commit("clearCart");
                this.$navigateTo(Home, {
                    clearHistory: true
                });
            },
            clear() {
                this.$store.commit("clearCart");
                this.$navigateTo(Home, {
                    clearHistory: true
                });
            }
        }
    };
</script>

<style>
</style>