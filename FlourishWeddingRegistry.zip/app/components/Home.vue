<template>
    <Page>
        <ActionBar title="Wedding Registry"></ActionBar>
        <ScrollView>
            <StackLayout backgroundColor="lightyellow">
                <registry-item name="King Bed" image="~/images/BedEx.jpg"
                    price="399">
                </registry-item>
                <registry-item name="Light Sofa" image="~/images/sofa-1.jpg"
                    price="299">
                </registry-item>
                <registry-item name="Dark Sofa" image="~/images/dark-sofa.jpg"
                    price="199">
                </registry-item>
                <Label class="productName" textWrap="true"
                    horizontalAlignment="center">Your budget is ${{ budget }}.
                </Label>
                <Label class="productName" horizontalAlignment="center"
                    textWrap="true">Cart size ${{ count }}.</Label>
                <Label class="productName" horizontalAlignment="center"
                    text="" textWrap="true"></Label>
                <Button text="Proceed to Checkout" class="btn-primary"
                    @tap="checkout" verticalAlignment="bottom" />
        </ScrollView>
        </StackLayout>
    </Page>
</template>

<script>
    import Login from "./Login";
    import {
        store
    } from "../store.js";
    import Cart from "./Cart";
    export default {
        data() {
            return {
                budget: this.$store.state.budget
            };
        },
        store,
        computed: {
            count() {
                return this.$store.state.cartSize.toString();
            }
        },
        methods: {
            checkout() {
                this.$navigateTo(Cart);
            }
        }
    };
</script>

<style>
</style>