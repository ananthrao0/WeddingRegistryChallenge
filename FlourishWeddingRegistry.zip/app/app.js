import Vue from "nativescript-vue";
import routes from "./routes";
import BackendService from "./services/backend-service";

// Uncommment the following to see NativeScript-Vue output logs
Vue.config.silent = false;

var cartCount;
cartCount = 0;
const backendService = new BackendService();
Vue.prototype.$backendService = backendService;

import { store } from "./store.js";

Vue.component("registry-item", {
  props: {
    name: {
      type: String,
      required: true
    },
    image: {
      type: String,
      required: true
    },
    price: {
      type: String,
      required: true
    }
  },
  template: `
  <StackLayout>
    <Image row=1 class="productImage" :src=image></Image>
    <GridLayout row=2 verticalAlignment="top">
    <Label> {{ name }}: \${{ price }} </Label>
    <Button horizontalAlignment="right" @tap="addToCart" text="Add to cart" class="btn btn-primary m-t-50" :isEnabled="parseInt(price, 10) <= this.$store.state.budget"></Button>
    </GridLayout>
  </StackLayout>`,
  store: store,
  data: function () {
    return {
    };
  },
  methods: {
    addToCart() {
      this.increment();
      this.addItem(this.name);
      this.incCartSize(this.price);
    },
    increment() {
      this.$store.commit('increment')
      //    console.log(this.$store.state.count)
    },
    addItem(name) {
      this.$store.commit('addItem', name);
      //     console.log(this.$store.state.itemsBought)
    },
    incCartSize(price) {
      this.$store.commit('increaseCartSize', parseInt(price, 10));
    }
  }
});

new Vue({
  render: h => h("frame", [h(backendService.isLoggedIn() ? routes.home : routes.login)])
}).$start();
