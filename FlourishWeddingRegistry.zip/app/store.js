import Vue from "nativescript-vue";
import Vuex from '~/vuex';

Vue.use(Vuex)

export const store = new Vuex.Store({
    state: {
        count: 0,
        budget: 1000,
        itemsBought: [],
        cartSize: 0
    },
    mutations: {
        increment(state) {
            state.count++
        },
        addItem(state, elem) {
            state.itemsBought.push(" " + elem);
        },
        decreaseBudget(state, price) {
            state.budget -= price;
        },
        increaseCartSize(state, price) {
            state.cartSize += price;
        },
        clearCart(state) {
            state.itemsBought = [];
            state.count = 0;
            state.cartSize = 0;
        }
    }
})